#ifndef PARTICLE_COUNT
#define PARTICLE_COUNT (1 << 15)
#endif
